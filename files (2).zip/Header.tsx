// components/layout/Header.tsx
'use client';

import React, { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { signOut } from 'next-auth/react';
import {
  Package,
  User,
  MapPin,
  Settings,
  ShieldCheck,
  LogOut,
  ChevronDown,
  Loader2,
  AlertCircle,
} from 'lucide-react';
import { useAuthSession, useIsAdmin } from '@/hooks/useAuthSession';

interface MenuItem {
  label: string;
  href: string;
  icon: React.ReactNode;
  description?: string;
  divider?: boolean;
}

export function Header() {
  const router = useRouter();
  const { session, status, isHydrated } = useAuthSession();
  const isAdmin = useIsAdmin();
  
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isSigningOut, setIsSigningOut] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  // Get user initials for avatar
  const getUserInitial = (): string => {
    const name = session?.user?.name || '';
    return name.charAt(0).toUpperCase() || 'U';
  };

  // Get user role badge
  const getRoleBadge = (): string => {
    const role = session?.user?.role;
    if (role === 'ADMIN') return 'ADMINISTRATOR';
    if (role === 'CUSTOMER') return 'VERIFIED CUSTOMER';
    return 'GUEST';
  };

  // Authenticated user menu items
  const authenticatedMenuItems: MenuItem[] = [
    {
      label: 'My Orders & Tracking',
      href: '/account?tab=orders',
      icon: <Package className="w-4 h-4" />,
      description: 'View and track your orders',
    },
    {
      label: 'Profile & Security',
      href: '/account?tab=profile',
      icon: <User className="w-4 h-4" />,
      description: 'Update personal information',
    },
    {
      label: 'Saved Addresses',
      href: '/account?tab=addresses',
      icon: <MapPin className="w-4 h-4" />,
      description: 'Manage delivery addresses',
    },
    {
      label: 'Account Settings',
      href: '/account?tab=profile',
      icon: <Settings className="w-4 h-4" />,
      description: 'Preferences and privacy',
    },
    ...(isAdmin
      ? [
          {
            label: 'Admin Console',
            href: '/admin/orders',
            icon: <ShieldCheck className="w-4 h-4" />,
            description: 'Manage store and orders',
            divider: true,
          },
        ]
      : []),
  ];

  // Handle dropdown click-outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        triggerRef.current &&
        !triggerRef.current.contains(event.target as Node)
      ) {
        setIsDropdownOpen(false);
      }
    };

    if (isDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isDropdownOpen]);

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && isDropdownOpen) {
        setIsDropdownOpen(false);
        triggerRef.current?.focus();
      }
    };

    if (isDropdownOpen) {
      document.addEventListener('keydown', handleKeyDown);
      return () => document.removeEventListener('keydown', handleKeyDown);
    }
  }, [isDropdownOpen]);

  // Handle menu item click
  const handleMenuItemClick = (href: string) => {
    setIsDropdownOpen(false);
    router.push(href);
  };

  // Handle sign out
  const handleSignOut = async () => {
    try {
      setIsSigningOut(true);
      await signOut({ redirect: true, callbackUrl: '/' });
    } catch (error) {
      console.error('Sign out error:', error);
      setIsSigningOut(false);
    }
  };

  // Loading state - show spinner until hydrated
  if (!isHydrated || status === 'loading') {
    return <HeaderSkeleton />;
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-200 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="text-2xl font-bold text-slate-900">
          Star Press
        </Link>

        {/* Profile Button & Dropdown */}
        <div className="relative">
          {status === 'authenticated' && session ? (
            <AuthenticatedMenu
              session={session}
              isDropdownOpen={isDropdownOpen}
              setIsDropdownOpen={setIsDropdownOpen}
              triggerRef={triggerRef}
              dropdownRef={dropdownRef}
              getUserInitial={getUserInitial}
              getRoleBadge={getRoleBadge}
              authenticatedMenuItems={authenticatedMenuItems}
              onMenuItemClick={handleMenuItemClick}
              isSigningOut={isSigningOut}
              onSignOut={handleSignOut}
            />
          ) : (
            <UnauthenticatedMenu
              isDropdownOpen={isDropdownOpen}
              setIsDropdownOpen={setIsDropdownOpen}
              triggerRef={triggerRef}
              dropdownRef={dropdownRef}
            />
          )}
        </div>
      </div>
    </header>
  );
}

// Authenticated Menu Component
function AuthenticatedMenu({
  session,
  isDropdownOpen,
  setIsDropdownOpen,
  triggerRef,
  dropdownRef,
  getUserInitial,
  getRoleBadge,
  authenticatedMenuItems,
  onMenuItemClick,
  isSigningOut,
  onSignOut,
}: {
  session: any;
  isDropdownOpen: boolean;
  setIsDropdownOpen: (open: boolean) => void;
  triggerRef: React.RefObject<HTMLButtonElement>;
  dropdownRef: React.RefObject<HTMLDivElement>;
  getUserInitial: () => string;
  getRoleBadge: () => string;
  authenticatedMenuItems: MenuItem[];
  onMenuItemClick: (href: string) => void;
  isSigningOut: boolean;
  onSignOut: () => Promise<void>;
}) {
  return (
    <>
      {/* Trigger Button */}
      <button
        ref={triggerRef}
        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-100 transition-colors"
        aria-haspopup="menu"
        aria-expanded={isDropdownOpen}
        aria-label="User menu"
      >
        {/* Avatar */}
        <div
          className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold text-sm text-white transition-all ${
            session.user.role === 'ADMIN'
              ? 'bg-gradient-to-br from-cyan-400 to-cyan-600'
              : 'bg-gradient-to-br from-blue-400 to-blue-600'
          }`}
        >
          {getUserInitial()}
        </div>

        {/* Role indicator dot */}
        <div
          className={`w-2 h-2 rounded-full ${
            session.user.role === 'ADMIN' ? 'bg-cyan-500' : 'bg-green-500'
          }`}
        />

        {/* Chevron */}
        <ChevronDown
          className={`w-4 h-4 text-slate-600 transition-transform ${
            isDropdownOpen ? 'rotate-180' : ''
          }`}
        />
      </button>

      {/* Dropdown Menu */}
      {isDropdownOpen && (
        <div
          ref={dropdownRef}
          role="menu"
          className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden z-50"
        >
          {/* User Identity Banner */}
          <div className="px-4 py-4 bg-gradient-to-r from-slate-50 to-slate-100 border-b border-slate-200">
            <div className="flex items-start gap-3">
              <div
                className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg text-white flex-shrink-0 ${
                  session.user.role === 'ADMIN'
                    ? 'bg-gradient-to-br from-cyan-400 to-cyan-600'
                    : 'bg-gradient-to-br from-blue-400 to-blue-600'
                }`}
              >
                {getUserInitial()}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-slate-900 truncate">
                  {session.user.name}
                </h3>
                <p className="text-xs text-slate-600 truncate">{session.user.email}</p>
                <div className="mt-2 flex items-center gap-2">
                  <span
                    className={`inline-block px-2 py-1 rounded text-xs font-semibold ${
                      session.user.role === 'ADMIN'
                        ? 'bg-cyan-100 text-cyan-700'
                        : 'bg-green-100 text-green-700'
                    }`}
                  >
                    {getRoleBadge()}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Navigation Items */}
          <div className="py-2">
            {authenticatedMenuItems.map((item, index) => (
              <React.Fragment key={index}>
                {item.divider && <div className="border-t border-slate-200 my-1" />}
                <button
                  onClick={() => onMenuItemClick(item.href)}
                  className="w-full px-4 py-3 text-left hover:bg-slate-50 transition-colors flex items-start gap-3 group"
                  role="menuitem"
                >
                  <span className="text-slate-500 group-hover:text-slate-700 flex-shrink-0 mt-0.5">
                    {item.icon}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-900 group-hover:text-slate-700">
                      {item.label}
                    </p>
                    {item.description && (
                      <p className="text-xs text-slate-500">{item.description}</p>
                    )}
                  </div>
                </button>
              </React.Fragment>
            ))}
          </div>

          {/* Sign Out Button */}
          <div className="border-t border-slate-200 p-2">
            <button
              onClick={onSignOut}
              disabled={isSigningOut}
              className="w-full px-4 py-3 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
              role="menuitem"
            >
              {isSigningOut ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Signing out...
                </>
              ) : (
                <>
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </>
  );
}

// Unauthenticated Menu Component
function UnauthenticatedMenu({
  isDropdownOpen,
  setIsDropdownOpen,
  triggerRef,
  dropdownRef,
}: {
  isDropdownOpen: boolean;
  setIsDropdownOpen: (open: boolean) => void;
  triggerRef: React.RefObject<HTMLButtonElement>;
  dropdownRef: React.RefObject<HTMLDivElement>;
}) {
  return (
    <>
      {/* Trigger Button */}
      <button
        ref={triggerRef}
        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-100 transition-colors"
        aria-haspopup="menu"
        aria-expanded={isDropdownOpen}
        aria-label="Guest menu"
      >
        <User className="w-5 h-5 text-slate-600" />
        <ChevronDown
          className={`w-4 h-4 text-slate-600 transition-transform ${
            isDropdownOpen ? 'rotate-180' : ''
          }`}
        />
      </button>

      {/* Dropdown Menu */}
      {isDropdownOpen && (
        <div
          ref={dropdownRef}
          role="menu"
          className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden z-50"
        >
          {/* Guest Welcome Banner */}
          <div className="px-4 py-6 bg-gradient-to-br from-blue-50 to-indigo-50 border-b border-slate-200 text-center">
            <h3 className="font-semibold text-slate-900 mb-2">
              Welcome to Star Press
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Sign in to access your print designs, past invoices, and saved delivery
              addresses. Create an account to get started.
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="p-4 space-y-3">
            <Link
              href="/login"
              className="block w-full px-4 py-3 bg-yellow-400 hover:bg-yellow-500 text-slate-900 font-semibold rounded-lg transition-colors text-center"
              role="menuitem"
            >
              Sign In
            </Link>
            <Link
              href="/register"
              className="block w-full px-4 py-3 border-2 border-slate-300 hover:border-slate-400 text-slate-900 font-semibold rounded-lg transition-colors text-center"
              role="menuitem"
            >
              Create Account
            </Link>
          </div>

          {/* Guest Helper */}
          <div className="px-4 py-3 bg-slate-50 border-t border-slate-200">
            <Link
              href="/account?tab=orders"
              className="flex items-center gap-2 text-sm text-slate-700 hover:text-slate-900 transition-colors"
              role="menuitem"
            >
              <Package className="w-4 h-4" />
              <span>Track an Order</span>
            </Link>
          </div>
        </div>
      )}
    </>
  );
}

// Skeleton Loader
function HeaderSkeleton() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-200 bg-white">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="w-24 h-8 bg-slate-200 rounded animate-pulse" />
        <div className="w-10 h-10 bg-slate-200 rounded-full animate-pulse" />
      </div>
    </header>
  );
}
