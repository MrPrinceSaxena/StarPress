// middleware.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { getToken } from 'next-auth/jwt';

const SECRET = process.env.NEXTAUTH_SECRET;

// Routes that require authentication
const PROTECTED_ROUTES = [
  '/account',
  '/admin',
  '/dashboard',
  '/orders',
  '/settings',
  '/saved-addresses',
];

// Routes that authenticated users should not access
const AUTH_ROUTES = [
  '/login',
  '/register',
  '/forgot-password',
  '/reset-password',
];

// Public routes (always accessible)
const PUBLIC_ROUTES = [
  '/',
  '/products',
  '/contact',
  '/privacy',
  '/terms',
];

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  try {
    // Get session token
    const token = await getToken({
      req: request,
      secret: SECRET,
    });

    const isAuthenticated = !!token;
    const userRole = token?.role as string | undefined;

    // CASE 1: Protected routes - redirect to login if not authenticated
    if (PROTECTED_ROUTES.some(route => pathname.startsWith(route))) {
      if (!isAuthenticated) {
        const loginUrl = new URL('/login', request.url);
        loginUrl.searchParams.set('callbackUrl', pathname);
        return NextResponse.redirect(loginUrl);
      }

      // Admin routes - check admin role
      if (pathname.startsWith('/admin') && userRole !== 'ADMIN') {
        return NextResponse.redirect(new URL('/account', request.url));
      }
    }

    // CASE 2: Auth routes - redirect to dashboard if already authenticated
    if (AUTH_ROUTES.some(route => pathname.startsWith(route))) {
      if (isAuthenticated) {
        // Redirect admin users to admin dashboard, others to account
        const redirectUrl = userRole === 'ADMIN' ? '/admin/orders' : '/account';
        
        // Preserve callback URL if it exists and is valid
        const callbackUrl = request.nextUrl.searchParams.get('callbackUrl');
        if (callbackUrl && !AUTH_ROUTES.some(route => callbackUrl.startsWith(route))) {
          return NextResponse.redirect(new URL(callbackUrl, request.url));
        }

        return NextResponse.redirect(new URL(redirectUrl, request.url));
      }
    }

    // CASE 3: Role-based access control
    if (pathname.startsWith('/admin') && userRole !== 'ADMIN') {
      return NextResponse.redirect(new URL('/account', request.url));
    }

    // CASE 4: Add security headers
    const response = NextResponse.next();
    response.headers.set('X-Content-Type-Options', 'nosniff');
    response.headers.set('X-Frame-Options', 'DENY');
    response.headers.set('X-XSS-Protection', '1; mode=block');
    response.headers.set(
      'Strict-Transport-Security',
      'max-age=31536000; includeSubDomains'
    );

    return response;
  } catch (error) {
    // If token validation fails, allow the request through
    // Client-side guards will handle auth checks
    console.error('[Middleware] Token validation error:', error);
    return NextResponse.next();
  }
}

// Configure which routes trigger middleware
export const config = {
  matcher: [
    // Protected routes
    '/account/:path*',
    '/admin/:path*',
    '/dashboard/:path*',
    '/orders/:path*',
    '/settings/:path*',
    '/saved-addresses/:path*',
    // Auth routes
    '/login',
    '/register',
    '/forgot-password',
    '/reset-password',
  ],
};
