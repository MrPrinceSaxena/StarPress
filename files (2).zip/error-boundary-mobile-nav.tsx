// components/ErrorBoundary.tsx
'use client';

import React, { ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class AuthErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('[Auth Error Boundary]', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-red-50 flex items-center justify-center p-4">
          <div className="max-w-md text-center">
            <AlertTriangle className="w-16 h-16 text-red-600 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-slate-900 mb-2">
              Something went wrong
            </h1>
            <p className="text-slate-600 mb-6">
              {this.state.error?.message || 'An unexpected error occurred'}
            </p>
            <button
              onClick={() => window.location.reload()}
              className="flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors mx-auto"
            >
              <RefreshCw className="w-4 h-4" />
              Refresh Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// ============================================

// components/layout/MobileNavDrawer.tsx
'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { signOut } from 'next-auth/react';
import {
  Package,
  User,
  MapPin,
  Settings,
  ShieldCheck,
  LogOut,
  Menu,
  X,
  ChevronRight,
  Loader2,
} from 'lucide-react';
import { useAuthSession, useIsAdmin } from '@/hooks/useAuthSession';

export function MobileNavDrawer() {
  const [isOpen, setIsOpen] = useState(false);
  const [isSigningOut, setIsSigningOut] = useState(false);
  const router = useRouter();
  const { session, status, isHydrated } = useAuthSession();
  const isAdmin = useIsAdmin();

  // Close drawer on route change
  useEffect(() => {
    setIsOpen(false);
  }, [router]);

  // Close drawer on escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen]);

  const handleSignOut = async () => {
    setIsSigningOut(true);
    await signOut({ redirect: true, callbackUrl: '/' });
  };

  const handleMenuItemClick = (href: string) => {
    router.push(href);
    setIsOpen(false);
  };

  const getUserInitial = (): string => {
    const name = session?.user?.name || '';
    return name.charAt(0).toUpperCase() || 'U';
  };

  if (!isHydrated) {
    return <MobileNavSkeleton />;
  }

  return (
    <>
      {/* Mobile Menu Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="lg:hidden p-2 hover:bg-slate-100 rounded-lg transition-colors"
        aria-label="Toggle menu"
      >
        {isOpen ? (
          <X className="w-6 h-6 text-slate-900" />
        ) : (
          <Menu className="w-6 h-6 text-slate-900" />
        )}
      </button>

      {/* Mobile Drawer Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 lg:hidden z-40"
          onClick={() => setIsOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Mobile Drawer */}
      <div
        className={`fixed top-0 right-0 bottom-0 w-80 bg-white shadow-2xl transform transition-transform duration-300 ease-out z-50 lg:hidden overflow-y-auto ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Close Button */}
        <div className="sticky top-0 bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between">
          <span className="text-lg font-semibold text-slate-900">Menu</span>
          <button
            onClick={() => setIsOpen(false)}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {status === 'authenticated' && session ? (
            <>
              {/* User Card */}
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-200">
                <div className="flex items-center gap-3 mb-3">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold text-white text-sm ${
                      session.user.role === 'ADMIN'
                        ? 'bg-gradient-to-br from-cyan-400 to-cyan-600'
                        : 'bg-gradient-to-br from-blue-400 to-blue-600'
                    }`}
                  >
                    {getUserInitial()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-slate-900 text-sm truncate">
                      {session.user.name}
                    </p>
                    <p className="text-xs text-slate-600 truncate">
                      {session.user.email}
                    </p>
                  </div>
                </div>
                <span
                  className={`inline-block px-2 py-1 rounded text-xs font-semibold ${
                    session.user.role === 'ADMIN'
                      ? 'bg-cyan-100 text-cyan-700'
                      : 'bg-green-100 text-green-700'
                  }`}
                >
                  {session.user.role === 'ADMIN'
                    ? 'ADMINISTRATOR'
                    : 'VERIFIED CUSTOMER'}
                </span>
              </div>

              {/* Navigation Links */}
              <nav className="space-y-2 border-b border-slate-200 pb-4">
                <MobileNavLink
                  href="/account?tab=orders"
                  icon={<Package className="w-5 h-5" />}
                  label="My Orders & Tracking"
                  onClick={() => handleMenuItemClick('/account?tab=orders')}
                />
                <MobileNavLink
                  href="/account?tab=profile"
                  icon={<User className="w-5 h-5" />}
                  label="Profile & Security"
                  onClick={() => handleMenuItemClick('/account?tab=profile')}
                />
                <MobileNavLink
                  href="/account?tab=addresses"
                  icon={<MapPin className="w-5 h-5" />}
                  label="Saved Addresses"
                  onClick={() => handleMenuItemClick('/account?tab=addresses')}
                />
                <MobileNavLink
                  href="/account?tab=profile"
                  icon={<Settings className="w-5 h-5" />}
                  label="Account Settings"
                  onClick={() => handleMenuItemClick('/account?tab=profile')}
                />

                {isAdmin && (
                  <>
                    <div className="border-t border-slate-200 my-2" />
                    <MobileNavLink
                      href="/admin/orders"
                      icon={<ShieldCheck className="w-5 h-5" />}
                      label="Admin Console"
                      onClick={() => handleMenuItemClick('/admin/orders')}
                    />
                  </>
                )}
              </nav>

              {/* Sign Out Button */}
              <button
                onClick={handleSignOut}
                disabled={isSigningOut}
                className="w-full px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors flex items-center justify-center gap-2 font-medium disabled:opacity-50"
              >
                {isSigningOut ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Signing out...
                  </>
                ) : (
                  <>
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </>
                )}
              </button>
            </>
          ) : (
            <>
              {/* Guest Menu */}
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-200 text-center mb-6">
                <h3 className="font-semibold text-slate-900 mb-2">
                  Welcome to Star Press
                </h3>
                <p className="text-sm text-slate-600">
                  Sign in to access your designs and orders
                </p>
              </div>

              <div className="space-y-3">
                <Link
                  href="/login"
                  onClick={() => setIsOpen(false)}
                  className="block w-full px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors text-center"
                >
                  Sign In
                </Link>
                <Link
                  href="/register"
                  onClick={() => setIsOpen(false)}
                  className="block w-full px-4 py-3 border-2 border-slate-300 hover:border-slate-400 text-slate-900 font-semibold rounded-lg transition-colors text-center"
                >
                  Create Account
                </Link>
              </div>

              <div className="border-t border-slate-200 pt-4">
                <Link
                  href="/account?tab=orders"
                  onClick={() => setIsOpen(false)}
                  className="flex items-center gap-2 text-slate-700 hover:text-slate-900 transition-colors py-2"
                >
                  <Package className="w-4 h-4" />
                  <span className="text-sm font-medium">Track an Order</span>
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}

// Mobile Nav Link Component
function MobileNavLink({
  href,
  icon,
  label,
  onClick,
}: {
  href: string;
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-3 px-3 py-3 text-slate-700 hover:bg-slate-50 hover:text-slate-900 rounded-lg transition-colors text-left text-sm font-medium group"
    >
      <span className="text-slate-500 group-hover:text-slate-700">{icon}</span>
      <span className="flex-1">{label}</span>
      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-600" />
    </button>
  );
}

// Skeleton Loader
function MobileNavSkeleton() {
  return (
    <button className="lg:hidden p-2 animate-pulse">
      <div className="w-6 h-6 bg-slate-200 rounded" />
    </button>
  );
}
