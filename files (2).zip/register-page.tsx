// app/register/page.tsx
'use client';

import React, { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAuthSession } from '@/hooks/useAuthSession';
import { AlertCircle, Loader2, Eye, EyeOff, Check } from 'lucide-react';

function RegisterContent() {
  const router = useRouter();
  const { session, status, isHydrated } = useAuthSession();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isRedirecting, setIsRedirecting] = useState(false);

  const [passwordStrength, setPasswordStrength] = useState<'weak' | 'fair' | 'strong'>('weak');

  // HYDRATION SAFETY
  if (!isHydrated) {
    return <RegisterSkeleton />;
  }

  // AUTH PROTECTION: Redirect if already authenticated
  useEffect(() => {
    if (status === 'authenticated' && session) {
      setIsRedirecting(true);
      const redirectUrl = session.user?.role === 'ADMIN' ? '/admin/orders' : '/account';
      router.replace(redirectUrl);
    }
  }, [status, session, router]);

  // Show redirect screen if authenticated
  if (status === 'authenticated') {
    return <AuthenticatedRedirectScreen />;
  }

  // Validate form
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    if (!formData.email) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters';
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Check password strength
  const checkPasswordStrength = (password: string) => {
    if (!password) {
      setPasswordStrength('weak');
      return;
    }

    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*]/.test(password);
    const isLong = password.length >= 12;

    const strength =
      hasUpperCase && hasLowerCase && hasNumbers && isLong
        ? 'strong'
        : hasUpperCase && hasLowerCase && hasNumbers
        ? 'fair'
        : 'weak';

    setPasswordStrength(strength);
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);

    try {
      // Call registration API
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          password: formData.password,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        setErrors({ form: data.message || 'Registration failed' });
        setIsLoading(false);
        return;
      }

      // Successful registration - redirect to login
      setIsRedirecting(true);
      router.replace(`/login?email=${encodeURIComponent(formData.email)}`);
    } catch (error) {
      setErrors({
        form: 'An unexpected error occurred. Please try again.',
      });
      setIsLoading(false);
      console.error('Registration error:', error);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    if (name === 'password') {
      checkPasswordStrength(value);
    }

    // Clear error for this field
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Card */}
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
          {/* Header */}
          <div className="px-6 py-8 bg-gradient-to-br from-slate-50 to-slate-100 border-b border-slate-200">
            <h1 className="text-2xl font-bold text-slate-900 mb-2">Create Account</h1>
            <p className="text-slate-600 text-sm">
              Join Star Press and start printing your designs
            </p>
          </div>

          {/* Content */}
          <div className="px-6 py-8">
            {/* Form Error */}
            {errors.form && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex gap-3">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm font-medium text-red-900">{errors.form}</p>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Name Field */}
              <div>
                <label className="block text-sm font-medium text-slate-900 mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  disabled={isLoading}
                  placeholder="John Doe"
                  className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 disabled:bg-slate-50 disabled:text-slate-500 ${
                    errors.name ? 'border-red-400 focus:border-red-500' : 'border-slate-300 focus:border-blue-500'
                  }`}
                />
                {errors.name && (
                  <p className="mt-1 text-sm text-red-600">{errors.name}</p>
                )}
              </div>

              {/* Email Field */}
              <div>
                <label className="block text-sm font-medium text-slate-900 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  disabled={isLoading}
                  placeholder="you@example.com"
                  className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 disabled:bg-slate-50 disabled:text-slate-500 ${
                    errors.email ? 'border-red-400 focus:border-red-500' : 'border-slate-300 focus:border-blue-500'
                  }`}
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-red-600">{errors.email}</p>
                )}
              </div>

              {/* Password Field */}
              <div>
                <label className="block text-sm font-medium text-slate-900 mb-2">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    disabled={isLoading}
                    placeholder="••••••••"
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 disabled:bg-slate-50 disabled:text-slate-500 ${
                      errors.password ? 'border-red-400 focus:border-red-500' : 'border-slate-300 focus:border-blue-500'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={isLoading}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-600 hover:text-slate-900 disabled:text-slate-400"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>

                {/* Password Strength Indicator */}
                {formData.password && (
                  <div className="mt-2">
                    <div className="flex gap-1 mb-1">
                      {['weak', 'fair', 'strong'].map((level) => (
                        <div
                          key={level}
                          className={`flex-1 h-1 rounded-full ${
                            passwordStrength === 'weak'
                              ? level === 'weak'
                                ? 'bg-red-500'
                                : 'bg-slate-200'
                              : passwordStrength === 'fair'
                              ? ['weak', 'fair'].includes(level)
                                ? 'bg-yellow-500'
                                : 'bg-slate-200'
                              : 'bg-green-500'
                          }`}
                        />
                      ))}
                    </div>
                    <p className={`text-xs font-medium ${
                      passwordStrength === 'weak'
                        ? 'text-red-600'
                        : passwordStrength === 'fair'
                        ? 'text-yellow-600'
                        : 'text-green-600'
                    }`}>
                      Password strength: {passwordStrength.charAt(0).toUpperCase() + passwordStrength.slice(1)}
                    </p>
                  </div>
                )}

                {errors.password && (
                  <p className="mt-1 text-sm text-red-600">{errors.password}</p>
                )}
              </div>

              {/* Confirm Password Field */}
              <div>
                <label className="block text-sm font-medium text-slate-900 mb-2">
                  Confirm Password
                </label>
                <div className="relative">
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    name="confirmPassword"
                    value={formData.confirmPassword}
                    onChange={handleInputChange}
                    disabled={isLoading}
                    placeholder="••••••••"
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 disabled:bg-slate-50 disabled:text-slate-500 ${
                      errors.confirmPassword ? 'border-red-400 focus:border-red-500' : 'border-slate-300 focus:border-blue-500'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    disabled={isLoading}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-600 hover:text-slate-900 disabled:text-slate-400"
                  >
                    {showConfirmPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
                {errors.confirmPassword && (
                  <p className="mt-1 text-sm text-red-600">{errors.confirmPassword}</p>
                )}
              </div>

              {/* Terms Checkbox */}
              <div className="flex items-start gap-2 py-2">
                <input
                  type="checkbox"
                  id="terms"
                  required
                  disabled={isLoading}
                  className="mt-1"
                />
                <label htmlFor="terms" className="text-xs text-slate-600">
                  I agree to the{' '}
                  <Link href="/terms" className="text-blue-600 hover:text-blue-700 font-medium">
                    Terms of Service
                  </Link>{' '}
                  and{' '}
                  <Link href="/privacy" className="text-blue-600 hover:text-blue-700 font-medium">
                    Privacy Policy
                  </Link>
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full mt-6 px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors disabled:bg-slate-400 flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Creating account...
                  </>
                ) : (
                  'Create Account'
                )}
              </button>
            </form>
          </div>

          {/* Divider */}
          <div className="px-6 py-4 border-t border-slate-200">
            <p className="text-center text-sm text-slate-600">
              Already have an account?{' '}
              <Link
                href="/login"
                className="font-semibold text-blue-600 hover:text-blue-700"
              >
                Sign in
              </Link>
            </p>
          </div>
        </div>

        {/* Security Info */}
        <div className="mt-8 space-y-2 text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-green-600" />
            <span>SSL encrypted - Your data is secure</span>
          </div>
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-green-600" />
            <span>No credit card required</span>
          </div>
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-green-600" />
            <span>14-day money-back guarantee</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// Authenticated Redirect Screen
function AuthenticatedRedirectScreen() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center p-4">
      <div className="text-center">
        <div className="mb-6 inline-block">
          <Loader2 className="w-12 h-12 animate-spin text-blue-600" />
        </div>
        <h1 className="text-2xl font-bold text-slate-900 mb-2">
          Already Signed In
        </h1>
        <p className="text-slate-600">
          You are already signed in. Redirecting to your account...
        </p>
      </div>
    </div>
  );
}

// Skeleton Loader
function RegisterSkeleton() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
          <div className="px-6 py-8 bg-gradient-to-br from-slate-50 to-slate-100 border-b border-slate-200">
            <div className="w-40 h-6 bg-slate-200 rounded animate-pulse mb-2" />
            <div className="w-56 h-4 bg-slate-200 rounded animate-pulse" />
          </div>
          <div className="px-6 py-8 space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i}>
                <div className="w-16 h-4 bg-slate-200 rounded animate-pulse mb-2" />
                <div className="w-full h-10 bg-slate-100 rounded animate-pulse" />
              </div>
            ))}
            <div className="w-full h-10 bg-slate-200 rounded animate-pulse mt-6" />
          </div>
        </div>
      </div>
    </div>
  );
}

// Wrapped with Suspense
export default function RegisterPage() {
  return (
    <Suspense fallback={<RegisterSkeleton />}>
      <RegisterContent />
    </Suspense>
  );
}
