// hooks/useAuthSession.ts
'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import { useSession } from 'next-auth/react';
import type { Session } from 'next-auth';

export interface AuthState {
  session: Session | null;
  status: 'loading' | 'authenticated' | 'unauthenticated';
  isHydrated: boolean;
  isRefreshing: boolean;
  error: Error | null;
}

const REFRESH_INTERVAL = 60000; // 60 seconds
const REAUTH_ATTEMPT_LIMIT = 3;

export function useAuthSession(): AuthState {
  const { data: session, status, update } = useSession();
  const [isHydrated, setIsHydrated] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const refreshTimeoutRef = useRef<NodeJS.Timeout>();
  const reAuthAttemptsRef = useRef(0);
  const lastRefreshRef = useRef<number>(0);

  // HYDRATION: Mark when component is mounted and ready
  useEffect(() => {
    setIsHydrated(true);
  }, []);

  // REAL-TIME SESSION REFRESH on visibility/focus
  const refreshSession = useCallback(async () => {
    // Debounce rapid refresh attempts
    const now = Date.now();
    if (now - lastRefreshRef.current < 5000) return;
    lastRefreshRef.current = now;

    try {
      setIsRefreshing(true);
      setError(null);
      
      // Validate session with server
      const response = await fetch('/api/auth/session', {
        method: 'GET',
        headers: { 'Cache-Control': 'no-cache' },
        credentials: 'include',
      });

      if (!response.ok) {
        if (response.status === 401) {
          // Session expired, clear local session
          await update(null);
          reAuthAttemptsRef.current = 0;
        } else {
          throw new Error(`Session refresh failed: ${response.statusText}`);
        }
      } else {
        const newSession = await response.json();
        if (newSession) {
          await update(newSession);
          reAuthAttemptsRef.current = 0; // Reset error counter
        }
      }
    } catch (err) {
      reAuthAttemptsRef.current++;
      const error = err instanceof Error ? err : new Error('Unknown session error');
      
      // Only set error if we've tried multiple times
      if (reAuthAttemptsRef.current >= REAUTH_ATTEMPT_LIMIT) {
        setError(error);
      }

      // Exponential backoff for retries
      const backoffDelay = Math.min(30000, 5000 * Math.pow(2, reAuthAttemptsRef.current));
      if (refreshTimeoutRef.current) clearTimeout(refreshTimeoutRef.current);
      refreshTimeoutRef.current = setTimeout(refreshSession, backoffDelay);
    } finally {
      setIsRefreshing(false);
    }
  }, [update]);

  // Periodic refresh interval
  useEffect(() => {
    if (!isHydrated) return;

    refreshTimeoutRef.current = setInterval(refreshSession, REFRESH_INTERVAL);

    return () => {
      if (refreshTimeoutRef.current) clearInterval(refreshTimeoutRef.current);
    };
  }, [isHydrated, refreshSession]);

  // Refresh on window visibility change
  useEffect(() => {
    if (!isHydrated) return;

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        refreshSession();
      }
    };

    const handleFocus = () => refreshSession();

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleFocus);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleFocus);
    };
  }, [isHydrated, refreshSession]);

  // Refresh on online event
  useEffect(() => {
    if (!isHydrated) return;

    const handleOnline = () => {
      refreshSession();
    };

    window.addEventListener('online', handleOnline);
    return () => window.removeEventListener('online', handleOnline);
  }, [isHydrated, refreshSession]);

  return {
    session,
    status: isHydrated ? status : 'loading',
    isHydrated,
    isRefreshing,
    error,
  };
}

/**
 * Hook to check if user is authenticated (with hydration safety)
 */
export function useIsAuthenticated(): boolean {
  const { status, isHydrated } = useAuthSession();
  return isHydrated && status === 'authenticated';
}

/**
 * Hook to check user role safely
 */
export function useUserRole(): string | null {
  const { session, isHydrated } = useAuthSession();
  return isHydrated && session?.user?.role ? (session.user.role as string) : null;
}

/**
 * Hook to check if user is admin
 */
export function useIsAdmin(): boolean {
  const role = useUserRole();
  return role === 'ADMIN';
}
