// app/account/page.tsx
'use client';

import React, { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useAuthSession } from '@/hooks/useAuthSession';
import { Package, User, MapPin, Settings, Loader2 } from 'lucide-react';

type TabType = 'orders' | 'profile' | 'addresses' | 'settings';

const TAB_CONFIG: Record<TabType, { label: string; icon: React.ReactNode }> = {
  orders: { label: 'My Orders', icon: <Package className="w-4 h-4" /> },
  profile: { label: 'Profile & Security', icon: <User className="w-4 h-4" /> },
  addresses: { label: 'Saved Addresses', icon: <MapPin className="w-4 h-4" /> },
  settings: { label: 'Settings', icon: <Settings className="w-4 h-4" /> },
};

export default function AccountPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { session, status, isHydrated } = useAuthSession();
  
  const [activeTab, setActiveTab] = useState<TabType>('orders');
  const [isTransitioning, setIsTransitioning] = useState(false);

  // HYDRATION & AUTH CHECK
  useEffect(() => {
    if (!isHydrated) return;
    
    if (status === 'unauthenticated') {
      router.replace('/login?callbackUrl=/account');
    }
  }, [isHydrated, status, router]);

  // DEEP-LINKING: Read tab from URL search params
  useEffect(() => {
    const tabParam = searchParams.get('tab') as TabType | null;
    
    if (tabParam && tabParam in TAB_CONFIG) {
      setActiveTab(tabParam);
    } else if (tabParam === 'settings') {
      // Map 'settings' to 'profile' tab
      setActiveTab('profile');
    } else {
      setActiveTab('orders');
    }
  }, [searchParams]);

  // Handle tab change with URL update
  const handleTabChange = (tab: TabType) => {
    setIsTransitioning(true);
    setActiveTab(tab);
    
    // Update URL without full page reload
    router.replace(`/account?tab=${tab}`, { scroll: false });
    
    // Simulate transition delay
    setTimeout(() => setIsTransitioning(false), 300);
  };

  // Loading state
  if (!isHydrated || status === 'loading') {
    return <AccountPageSkeleton />;
  }

  // Unauthenticated redirect
  if (status === 'unauthenticated') {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-slate-400" />
        <p className="text-slate-600">Redirecting to login...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            Welcome back, {session?.user?.name?.split(' ')[0]}!
          </h1>
          <p className="text-slate-600">Manage your account and orders</p>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white rounded-lg border border-slate-200 mb-6">
          <div className="flex border-b border-slate-200">
            {(Object.entries(TAB_CONFIG) as [TabType, typeof TAB_CONFIG[TabType]][]).map(
              ([tabKey, tabData]) => (
                <button
                  key={tabKey}
                  onClick={() => handleTabChange(tabKey)}
                  className={`flex-1 px-6 py-4 text-sm font-medium transition-colors border-b-2 flex items-center justify-center gap-2 ${
                    activeTab === tabKey
                      ? 'text-blue-600 border-blue-600'
                      : 'text-slate-600 border-transparent hover:text-slate-900 hover:bg-slate-50'
                  }`}
                  aria-selected={activeTab === tabKey}
                  role="tab"
                >
                  {tabData.icon}
                  {tabData.label}
                </button>
              )
            )}
          </div>

          {/* Tab Content */}
          <div className="p-6">
            {isTransitioning ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
              </div>
            ) : (
              <>
                {activeTab === 'orders' && <OrdersTab />}
                {activeTab === 'profile' && <ProfileTab user={session?.user} />}
                {activeTab === 'addresses' && <AddressesTab />}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ORDERS TAB
function OrdersTab() {
  const [orders, setOrders] = React.useState([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    const fetchOrders = async () => {
      try {
        setIsLoading(true);
        const response = await fetch('/api/orders', {
          credentials: 'include',
        });

        if (!response.ok) {
          throw new Error('Failed to fetch orders');
        }

        const data = await response.json();
        setOrders(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
      } finally {
        setIsLoading(false);
      }
    };

    fetchOrders();
  }, []);

  if (isLoading) {
    return <div className="text-center py-8"><Loader2 className="w-6 h-6 animate-spin mx-auto" /></div>;
  }

  if (error) {
    return <div className="text-red-600 py-8 text-center">{error}</div>;
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-12">
        <Package className="w-12 h-12 text-slate-300 mx-auto mb-4" />
        <p className="text-slate-600 mb-4">No orders yet</p>
        <a href="/products" className="text-blue-600 hover:text-blue-700 font-medium">
          Start shopping →
        </a>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {orders.map((order: any) => (
        <div
          key={order.id}
          className="border border-slate-200 rounded-lg p-4 hover:border-slate-300 transition-colors"
        >
          <div className="flex items-center justify-between mb-2">
            <div>
              <p className="font-semibold text-slate-900">Order #{order.id}</p>
              <p className="text-sm text-slate-600">
                {new Date(order.createdAt).toLocaleDateString()}
              </p>
            </div>
            <div className="text-right">
              <p className="font-semibold text-slate-900">${order.total.toFixed(2)}</p>
              <p
                className={`text-sm font-medium ${
                  order.status === 'delivered'
                    ? 'text-green-600'
                    : order.status === 'shipped'
                    ? 'text-blue-600'
                    : 'text-slate-600'
                }`}
              >
                {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
              </p>
            </div>
          </div>
          <a
            href={`/orders/${order.id}`}
            className="text-blue-600 hover:text-blue-700 text-sm font-medium"
          >
            View Details →
          </a>
        </div>
      ))}
    </div>
  );
}

// PROFILE TAB
function ProfileTab({ user }: { user: any }) {
  const [isEditing, setIsEditing] = React.useState(false);
  const [formData, setFormData] = React.useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
  });

  const handleSave = async () => {
    try {
      const response = await fetch('/api/user/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
        credentials: 'include',
      });

      if (response.ok) {
        setIsEditing(false);
        // Optionally show success message
      }
    } catch (error) {
      console.error('Failed to update profile:', error);
    }
  };

  return (
    <div className="max-w-2xl">
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-slate-900 mb-2">
            Full Name
          </label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            disabled={!isEditing}
            className="w-full px-4 py-2 border border-slate-200 rounded-lg disabled:bg-slate-50 disabled:text-slate-600"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-900 mb-2">
            Email
          </label>
          <input
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            disabled={!isEditing}
            className="w-full px-4 py-2 border border-slate-200 rounded-lg disabled:bg-slate-50 disabled:text-slate-600"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-900 mb-2">
            Phone
          </label>
          <input
            type="tel"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            disabled={!isEditing}
            className="w-full px-4 py-2 border border-slate-200 rounded-lg disabled:bg-slate-50 disabled:text-slate-600"
          />
        </div>

        <div className="flex gap-3">
          {!isEditing ? (
            <button
              onClick={() => setIsEditing(true)}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Edit Profile
            </button>
          ) : (
            <>
              <button
                onClick={handleSave}
                className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                Save Changes
              </button>
              <button
                onClick={() => {
                  setIsEditing(false);
                  setFormData({
                    name: user?.name || '',
                    email: user?.email || '',
                    phone: user?.phone || '',
                  });
                }}
                className="px-6 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ADDRESSES TAB
function AddressesTab() {
  const [addresses, setAddresses] = React.useState([]);
  const [isLoading, setIsLoading] = React.useState(true);

  React.useEffect(() => {
    const fetchAddresses = async () => {
      try {
        const response = await fetch('/api/addresses', {
          credentials: 'include',
        });
        const data = await response.json();
        setAddresses(data);
      } catch (error) {
        console.error('Failed to fetch addresses:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchAddresses();
  }, []);

  if (isLoading) {
    return <div className="text-center py-8"><Loader2 className="w-6 h-6 animate-spin mx-auto" /></div>;
  }

  if (addresses.length === 0) {
    return (
      <div className="text-center py-12">
        <MapPin className="w-12 h-12 text-slate-300 mx-auto mb-4" />
        <p className="text-slate-600 mb-4">No saved addresses</p>
        <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          Add Address
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {addresses.map((address: any) => (
        <div
          key={address.id}
          className="border border-slate-200 rounded-lg p-4 hover:border-slate-300 transition-colors"
        >
          <div className="flex items-start justify-between">
            <div>
              <p className="font-semibold text-slate-900">{address.label}</p>
              <p className="text-sm text-slate-600 mt-1">{address.street}</p>
              <p className="text-sm text-slate-600">
                {address.city}, {address.state} {address.zip}
              </p>
            </div>
            {address.isDefault && (
              <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded">
                Default
              </span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

// Skeleton Loader
function AccountPageSkeleton() {
  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 space-y-4">
          <div className="w-64 h-10 bg-slate-200 rounded animate-pulse" />
          <div className="w-48 h-4 bg-slate-200 rounded animate-pulse" />
        </div>

        <div className="bg-white rounded-lg border border-slate-200">
          <div className="flex border-b border-slate-200">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="flex-1 px-6 py-4 h-16 bg-slate-100 animate-pulse"
              />
            ))}
          </div>
          <div className="p-6 space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 bg-slate-100 rounded animate-pulse" />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
