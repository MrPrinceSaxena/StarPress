// app/login/page.tsx
'use client';

import React, { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { signIn } from 'next-auth/react';
import { useAuthSession } from '@/hooks/useAuthSession';
import { AlertCircle, Loader2, Eye, EyeOff } from 'lucide-react';

function LoginContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { session, status, isHydrated } = useAuthSession();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isRedirecting, setIsRedirecting] = useState(false);

  const callbackUrl = searchParams.get('callbackUrl') || '/account';

  // HYDRATION SAFETY: Don't render until hydrated
  if (!isHydrated) {
    return <LoginSkeleton />;
  }

  // AUTH PROTECTION: Redirect if already authenticated
  useEffect(() => {
    if (status === 'authenticated' && session) {
      setIsRedirecting(true);
      
      const redirectUrl = session.user?.role === 'ADMIN' ? '/admin/orders' : callbackUrl;
      
      // Use replace to avoid adding to browser history
      router.replace(redirectUrl);
    }
  }, [status, session, router, callbackUrl]);

  // Show redirect screen if authenticated
  if (status === 'authenticated') {
    return <AuthenticatedRedirectScreen />;
  }

  // Handle login form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      // Validate inputs
      if (!email || !password) {
        setError('Please enter both email and password');
        setIsLoading(false);
        return;
      }

      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        setError('Please enter a valid email address');
        setIsLoading(false);
        return;
      }

      // Sign in with credentials
      const result = await signIn('credentials', {
        email,
        password,
        redirect: false,
      });

      if (!result?.ok) {
        if (result?.error === 'CredentialsSignin') {
          setError('Invalid email or password');
        } else if (result?.error === 'AccessDenied') {
          setError('Account access denied. Please contact support.');
        } else {
          setError(result?.error || 'Failed to sign in');
        }
        setIsLoading(false);
        return;
      }

      // Successful sign in
      setIsRedirecting(true);
      router.replace(callbackUrl);
    } catch (err) {
      setError('An unexpected error occurred. Please try again.');
      setIsLoading(false);
      console.error('Login error:', err);
    }
  };

  // Demo credentials for testing
  const fillDemoCustomer = () => {
    setEmail('customer@starpress.in');
    setPassword('Customer@StarPress2026');
  };

  const fillDemoAdmin = () => {
    setEmail('admin@starpress.in');
    setPassword('Admin@StarPress2026');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Card */}
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
          {/* Header */}
          <div className="px-6 py-8 bg-gradient-to-br from-slate-50 to-slate-100 border-b border-slate-200">
            <h1 className="text-2xl font-bold text-slate-900 mb-2">Welcome Back</h1>
            <p className="text-slate-600 text-sm">
              Sign in to your Star Press account
            </p>
          </div>

          {/* Content */}
          <div className="px-6 py-8">
            {/* Error Alert */}
            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex gap-3">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-red-900">{error}</p>
                </div>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Email Field */}
              <div>
                <label className="block text-sm font-medium text-slate-900 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isLoading}
                  placeholder="you@example.com"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 disabled:bg-slate-50 disabled:text-slate-500"
                />
              </div>

              {/* Password Field */}
              <div>
                <label className="block text-sm font-medium text-slate-900 mb-2">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    disabled={isLoading}
                    placeholder="••••••••"
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 disabled:bg-slate-50 disabled:text-slate-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={isLoading}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-600 hover:text-slate-900 disabled:text-slate-400"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full mt-6 px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors disabled:bg-slate-400 flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  'Sign In'
                )}
              </button>
            </form>

            {/* Forgot Password Link */}
            <div className="mt-4 text-center">
              <Link
                href="/forgot-password"
                className="text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                Forgot your password?
              </Link>
            </div>
          </div>

          {/* Divider */}
          <div className="px-6 py-4 border-t border-slate-200">
            <p className="text-center text-sm text-slate-600">
              Don't have an account?{' '}
              <Link
                href="/register"
                className="font-semibold text-blue-600 hover:text-blue-700"
              >
                Create one
              </Link>
            </p>
          </div>

          {/* Demo Credentials (Development Only) */}
          {process.env.NODE_ENV === 'development' && (
            <div className="px-6 py-4 bg-amber-50 border-t border-amber-200">
              <p className="text-xs font-semibold text-amber-900 mb-3">
                Demo Credentials (Dev Only)
              </p>
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={fillDemoCustomer}
                  disabled={isLoading}
                  className="w-full text-left px-3 py-2 text-xs bg-white border border-amber-200 rounded text-amber-900 hover:bg-amber-100 transition-colors disabled:opacity-50"
                >
                  👤 Customer: customer@starpress.in
                </button>
                <button
                  type="button"
                  onClick={fillDemoAdmin}
                  disabled={isLoading}
                  className="w-full text-left px-3 py-2 text-xs bg-white border border-amber-200 rounded text-amber-900 hover:bg-amber-100 transition-colors disabled:opacity-50"
                >
                  👨‍💼 Admin: admin@starpress.in
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Trust Badges */}
        <div className="mt-8 grid grid-cols-3 gap-4 text-center text-xs text-slate-600">
          <div>🔒 Secure Login</div>
          <div>🛡️ Data Protected</div>
          <div>✓ Verified</div>
        </div>
      </div>
    </div>
  );
}

// Authenticated Redirect Screen (shown while redirecting)
function AuthenticatedRedirectScreen() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center p-4">
      <div className="text-center">
        <div className="mb-6 inline-block">
          <Loader2 className="w-12 h-12 animate-spin text-blue-600" />
        </div>
        <h1 className="text-2xl font-bold text-slate-900 mb-2">
          Already Signed In
        </h1>
        <p className="text-slate-600">
          You are already signed in. Redirecting to your account...
        </p>
      </div>
    </div>
  );
}

// Skeleton Loader
function LoginSkeleton() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
          <div className="px-6 py-8 bg-gradient-to-br from-slate-50 to-slate-100 border-b border-slate-200">
            <div className="w-32 h-6 bg-slate-200 rounded animate-pulse mb-2" />
            <div className="w-40 h-4 bg-slate-200 rounded animate-pulse" />
          </div>
          <div className="px-6 py-8 space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i}>
                <div className="w-16 h-4 bg-slate-200 rounded animate-pulse mb-2" />
                <div className="w-full h-10 bg-slate-100 rounded animate-pulse" />
              </div>
            ))}
            <div className="w-full h-10 bg-slate-200 rounded animate-pulse mt-6" />
          </div>
        </div>
      </div>
    </div>
  );
}

// Wrapped with Suspense
export default function LoginPage() {
  return (
    <Suspense fallback={<LoginSkeleton />}>
      <LoginContent />
    </Suspense>
  );
}
