# PRODUCTION-GRADE AUTH SYSTEM - IMPLEMENTATION GUIDE

## ✅ COMPLETE CHECKLIST

### FILES TO CREATE/UPDATE

```
src/
├── hooks/
│   └── useAuthSession.ts              ✓ (CREATED)
├── middleware.ts                      ✓ (CREATED)
├── components/
│   └── layout/
│       ├── Header.tsx                 ✓ (CREATED)
│       └── MobileNavDrawer.tsx        ✓ (CREATED)
├── app/
│   ├── login/
│   │   └── page.tsx                   ✓ (CREATED)
│   ├── register/
│   │   └── page.tsx                   ✓ (CREATED)
│   ├── account/
│   │   └── page.tsx                   ✓ (CREATED)
│   ├── api/
│   │   └── auth/
│   │       ├── session/
│   │       │   └── route.ts           ✓ (CREATED)
│   │       ├── register/
│   │       │   └── route.ts           ✓ (CREATED)
│   │       └── signout/
│   │           └── route.ts           ✓ (CREATED)
├── lib/
│   └── auth.ts                        ✓ (CREATED)
└── components/
    └── ErrorBoundary.tsx              ✓ (CREATED)
```

---

## 🚀 STEP-BY-STEP INSTALLATION

### 1. Install Dependencies

```bash
npm install next-auth@5 bcryptjs
npm install -D @types/bcryptjs
```

### 2. Environment Setup

Create `.env.local`:

```env
# NextAuth
NEXTAUTH_SECRET=your-super-secret-key-here
NEXTAUTH_URL=http://localhost:3000

# Database (adjust to your DB)
DATABASE_URL=your-database-url

# Optional: API endpoints
NEXT_PUBLIC_API_URL=http://localhost:3000
```

Generate NEXTAUTH_SECRET:
```bash
openssl rand -base64 32
```

### 3. Update Root Layout

```tsx
// app/layout.tsx
import { AuthProvider } from '@/components/providers/AuthProvider';
import { AuthErrorBoundary } from '@/components/ErrorBoundary';
import { Header } from '@/components/layout/Header';
import { MobileNavDrawer } from '@/components/layout/MobileNavDrawer';

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html>
      <body>
        <AuthErrorBoundary>
          <AuthProvider>
            <Header />
            <MobileNavDrawer />
            <main>{children}</main>
          </AuthProvider>
        </AuthErrorBoundary>
      </body>
    </html>
  );
}
```

### 4. Create Auth Provider

```tsx
// components/providers/AuthProvider.tsx
'use client';

import { SessionProvider } from 'next-auth/react';
import { ReactNode } from 'react';

export function AuthProvider({ children }: { children: ReactNode }) {
  return (
    <SessionProvider
      refetchInterval={60} // Refresh every 60 seconds
      refetchOnWindowFocus={true}
      refetchOnReconnect={true}
    >
      {children}
    </SessionProvider>
  );
}
```

### 5. Update Prisma Schema (if using Prisma)

```prisma
model User {
  id            String    @id @default(cuid())
  name          String?
  email         String    @unique
  password      String
  emailVerified DateTime?
  image         String?
  role          String    @default("CUSTOMER") // CUSTOMER, ADMIN
  disabled      Boolean   @default(false)
  phone         String?
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt

  orders        Order[]
  addresses     Address[]
  sessions      Session[]
  accounts      Account[]
}

model Account {
  id                 String  @id @default(cuid())
  userId             String
  type               String
  provider           String
  providerAccountId  String
  refresh_token      String?
  access_token       String?
  expires_at         Int?
  token_type         String?
  scope              String?
  id_token           String?
  session_state      String?

  user User @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@unique([provider, providerAccountId])
}

model Session {
  id           String   @id @default(cuid())
  sessionToken String   @unique
  userId       String
  expires      DateTime
  user         User     @relation(fields: [userId], references: [id], onDelete: Cascade)
}

model Order {
  id        String   @id @default(cuid())
  userId    String
  total     Float
  status    String   @default("pending") // pending, shipped, delivered
  user      User     @relation(fields: [userId], references: [id])
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model Address {
  id       String @id @default(cuid())
  userId   String
  label    String
  street   String
  city     String
  state    String
  zip      String
  country  String @default("IN")
  isDefault Boolean @default(false)
  user     User   @relation(fields: [userId], references: [id])
}
```

Run migrations:
```bash
npx prisma migrate dev --name init
```

---

## 🧪 TESTING CHECKLIST

### SCENARIO 1: Unauthenticated User

**Test 1.1: Profile Icon Shows Guest Menu**
- [ ] Navigate to homepage
- [ ] Click profile icon in Header
- [ ] Verify dropdown shows:
  - [ ] "Welcome to Star Press" greeting
  - [ ] "Sign In" button
  - [ ] "Create Account" button
  - [ ] "Track an Order" link

**Test 1.2: Clicking Sign In/Register Works**
- [ ] Click "Sign In" → navigates to `/login`
- [ ] Click "Create Account" → navigates to `/register`
- [ ] Click "Track an Order" → navigates to `/account?tab=orders`

**Test 1.3: Create Account Flow**
- [ ] Fill form with valid data
- [ ] Password strength indicator shows correctly
- [ ] Submit → user created in database
- [ ] Redirect to login page with email pre-filled

**Test 1.4: Mobile Menu**
- [ ] Resize to mobile (< 1024px)
- [ ] Click menu icon
- [ ] Verify drawer opens with same options
- [ ] Click item → closes drawer and navigates

---

### SCENARIO 2: Authenticated User (Customer)

**Test 2.1: Profile Icon Shows User Menu**
- [ ] Sign in as customer@starpress.in / Customer@StarPress2026
- [ ] Click profile icon
- [ ] Verify dropdown shows:
  - [ ] User avatar with initial ("C")
  - [ ] User name and email
  - [ ] "VERIFIED CUSTOMER" badge (green)
  - [ ] My Orders & Tracking link
  - [ ] Profile & Security link
  - [ ] Saved Addresses link
  - [ ] Account Settings link
  - [ ] Sign Out button

**Test 2.2: Deep-Linked Tabs**
- [ ] Click "My Orders & Tracking" → redirects to `/account?tab=orders`
  - [ ] Orders tab is active
  - [ ] URL shows `?tab=orders`
- [ ] Click "Profile & Security" → redirects to `/account?tab=profile`
  - [ ] Profile tab is active
  - [ ] URL shows `?tab=profile`
- [ ] Click "Saved Addresses" → redirects to `/account?tab=addresses`
  - [ ] Addresses tab is active
  - [ ] URL shows `?tab=addresses`

**Test 2.3: Tab Persistence**
- [ ] Open `/account?tab=profile`
- [ ] Refresh page
- [ ] Verify Profile tab remains active
- [ ] Browser back button works correctly

**Test 2.4: Auth Protection on Login/Register**
- [ ] Already signed in, navigate to `/login`
  - [ ] See "Already Signed In. Redirecting..." message
  - [ ] Automatically redirected to `/account` (not logged out)
- [ ] Navigate to `/register`
  - [ ] Same redirect behavior

**Test 2.5: Sign Out**
- [ ] Click "Sign Out" button
- [ ] Verify loading state shows
- [ ] Redirect to homepage
- [ ] Profile icon now shows guest menu
- [ ] Session cleared from cookies

**Test 2.6: Real-Time Session Refresh**
- [ ] Sign in, keep tab open for 60+ seconds
- [ ] App should refresh session automatically
- [ ] Session remains valid
- [ ] No user-visible changes

**Test 2.7: Session on Window Focus**
- [ ] Sign in, minimize browser for 5+ minutes
- [ ] Return to browser/tab focus
- [ ] Session auto-refreshes
- [ ] No need to re-login

**Test 2.8: Mobile Experience**
- [ ] Sign in on mobile
- [ ] Click menu icon
- [ ] Verify user card shows with avatar, name, email, badge
- [ ] All menu links visible
- [ ] Sign Out works

---

### SCENARIO 3: Authenticated User (Admin)

**Test 3.1: Admin Badge and Admin Console Link**
- [ ] Sign in as admin@starpress.in / Admin@StarPress2026
- [ ] Click profile icon
- [ ] Verify:
  - [ ] Avatar has cyan gradient
  - [ ] Badge shows "ADMINISTRATOR"
  - [ ] Additional "Admin Console" link visible
  - [ ] Link points to `/admin/orders`

**Test 3.2: Admin Route Protection**
- [ ] Navigate to `/admin/orders`
  - [ ] Page loads (if admin role)
- [ ] Sign out
- [ ] Navigate to `/admin/orders`
  - [ ] Redirected to `/login` with `callbackUrl=/admin/orders`
- [ ] Sign in as non-admin
- [ ] Navigate to `/admin/orders`
  - [ ] Redirected to `/account` (access denied)

**Test 3.3: Mobile Admin Menu**
- [ ] Sign in as admin on mobile
- [ ] Open drawer
- [ ] Verify "Admin Console" link visible
- [ ] Click it → navigates to `/admin/orders`

---

### SCENARIO 4: Edge Cases

**Test 4.1: Rapid Tab Switching**
- [ ] Sign in
- [ ] Click between tabs rapidly
- [ ] Verify no errors/flashing
- [ ] URL updates correctly for each tab

**Test 4.2: Invalid Session Token**
- [ ] Manually delete session cookie
- [ ] Refresh page
- [ ] Should show redirect message
- [ ] Session auto-clears

**Test 4.3: Network Disconnection**
- [ ] Sign in
- [ ] Open DevTools → Network → Offline
- [ ] Try to click menu
- [ ] Should handle gracefully (no crash)
- [ ] Go back online
- [ ] Session auto-refreshes

**Test 4.4: Callback URL Redirect**
- [ ] Unauthenticated, navigate to `/account`
- [ ] Redirected to `/login?callbackUrl=/account`
- [ ] Sign in
- [ ] Should redirect to `/account` (original page)

**Test 4.5: Multiple Tabs/Windows**
- [ ] Open site in two tabs
- [ ] Sign in on Tab A
- [ ] Switch to Tab B (not yet signed in)
- [ ] Refresh Tab B
- [ ] Should show authenticated menu
- [ ] Sign out on Tab A
- [ ] Switch to Tab B
- [ ] Session should be invalid on focus/refresh

---

### SCENARIO 5: Error Handling

**Test 5.1: Invalid Login Credentials**
- [ ] Try signing in with wrong email/password
- [ ] Verify error message displays
- [ ] Form doesn't submit
- [ ] User stays on login page

**Test 5.2: Duplicate Email Registration**
- [ ] Try registering with existing email
- [ ] Verify error: "Email already registered"
- [ ] User stays on register page

**Test 5.3: Weak Password**
- [ ] Try registering with < 8 char password
- [ ] Verify error message
- [ ] Password strength indicator shows "weak"

**Test 5.4: Form Validation**
- [ ] Leave fields empty, try to submit
- [ ] Verify all errors display
- [ ] Try submitting with invalid email format
- [ ] Error displays for that field

---

## 🔒 SECURITY CHECKLIST

- [ ] NEXTAUTH_SECRET is strong and stored in `.env.local` (not committed)
- [ ] Passwords are hashed with bcryptjs (min 10 rounds)
- [ ] Cookies are HttpOnly and Secure
- [ ] CSRF protection enabled
- [ ] Session tokens are JWT-based
- [ ] Protected routes require valid session
- [ ] Admin routes check role on middleware + client
- [ ] No sensitive data in JWT (only id, role, email)
- [ ] Credentials provider validates on server
- [ ] Rate limiting on login/register endpoints (recommended)
- [ ] HTTPS enforced in production
- [ ] Security headers set (HSTS, X-Frame-Options, etc.)

---

## 📊 PERFORMANCE CHECKLIST

- [ ] Session refresh debounced (5s minimum interval)
- [ ] Page transitions use loading states
- [ ] No unnecessary re-renders (check with React DevTools)
- [ ] Mobile drawer is smooth and performant
- [ ] Tab switching doesn't cause full page reload
- [ ] Images lazy-loaded (avatars, etc.)
- [ ] No console errors in production build

---

## 🐛 COMMON ISSUES & FIXES

### Issue: "You are already signed in" screen keeps showing
**Fix:** Ensure `router.replace()` is called without `scroll: true`

### Issue: Session not persisting on refresh
**Fix:** Verify `SESSION_MAXAGE` is sufficient and JWT secret is correct

### Issue: Mobile drawer doesn't close on nav click
**Fix:** Call `setIsOpen(false)` in `onClick` handler for nav items

### Issue: Login form flashes before redirect
**Fix:** Check `isHydrated` state before rendering form content

### Issue: Admin routes accessible to non-admins
**Fix:** Add role check on both middleware AND client component

### Issue: Callback URL not working after login
**Fix:** Validate callback URL starts with `/` and doesn't contain auth routes

---

## 📈 MONITORING & ANALYTICS

Add to `authOptions.callbacks.signIn`:
```typescript
// Log successful sign-in
console.log('User signed in:', user.email);
// Track with analytics
analytics.event('user_signin', { email: user.email });
```

Monitor failed login attempts:
```typescript
// In CredentialsProvider.authorize()
if (!isPasswordValid) {
  analytics.event('failed_login', { email });
  // Consider rate limiting here
}
```

---

## 🎯 NEXT STEPS

1. **Email Verification** - Send verification email on registration
2. **Password Reset** - Implement forgot password flow
3. **OAuth** - Add Google/GitHub sign-in
4. **2FA** - Two-factor authentication for admin accounts
5. **Activity Logging** - Log all auth events for audit trail
6. **Rate Limiting** - Implement on login/register to prevent brute force
7. **Session Timeout** - Add idle timeout warning
8. **Passwordless Auth** - Magic link sign-in option

---

## 🚨 PRODUCTION DEPLOYMENT

Before deploying:

```bash
# 1. Type check
npx tsc --noEmit

# 2. Lint
npm run lint

# 3. Build
npm run build

# 4. Test
npm run test

# 5. Security audit
npm audit
```

Update production environment variables:
- [ ] `NEXTAUTH_SECRET` - generate new strong secret
- [ ] `NEXTAUTH_URL` - set to production domain
- [ ] `DATABASE_URL` - production database connection
- [ ] Enable HTTPS only cookies in production

---

## 📚 DOCUMENTATION LINKS

- [Next.js Documentation](https://nextjs.org/docs)
- [NextAuth.js Documentation](https://next-auth.js.org)
- [React Hooks Documentation](https://react.dev/reference/react)
- [Tailwind CSS](https://tailwindcss.com)
- [Lucide Icons](https://lucide.dev)

---

## 🤝 SUPPORT & TROUBLESHOOTING

If you encounter issues:

1. Check browser console for errors
2. Check server logs in terminal
3. Verify all environment variables are set
4. Clear cookies and try again
5. Check that database is running and connected

---

**Version:** 1.0  
**Last Updated:** 2024  
**Status:** Production Ready ✅
