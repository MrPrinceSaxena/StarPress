// app/api/auth/session/route.ts
import { getServerSession } from 'next-auth/next';
import { NextRequest, NextResponse } from 'next/server';
import { authOptions } from '@/lib/auth';

/**
 * GET /api/auth/session
 * 
 * Validates and returns current session
 * Used for real-time session refresh in useAuthSession hook
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    // Return 401 if no session
    if (!session) {
      return NextResponse.json(
        { error: 'No active session' },
        { status: 401 }
      );
    }

    // Add refresh timestamp
    return NextResponse.json(
      {
        ...session,
        refreshedAt: new Date().toISOString(),
      },
      {
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0',
        },
      }
    );
  } catch (error) {
    console.error('[Auth Session API] Error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// ============================================

// app/api/auth/register/route.ts
import { hash } from 'bcryptjs';
import { db } from '@/lib/db'; // Your database client

/**
 * POST /api/auth/register
 * 
 * Creates a new user account with validation
 */
export async function POST(request: NextRequest) {
  try {
    const { name, email, password } = await request.json();

    // VALIDATION
    if (!name || !email || !password) {
      return NextResponse.json(
        { message: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { message: 'Invalid email format' },
        { status: 400 }
      );
    }

    // Validate password strength
    if (password.length < 8) {
      return NextResponse.json(
        { message: 'Password must be at least 8 characters' },
        { status: 400 }
      );
    }

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email: email.toLowerCase() },
    });

    if (existingUser) {
      return NextResponse.json(
        { message: 'Email already registered' },
        { status: 409 }
      );
    }

    // Hash password
    const hashedPassword = await hash(password, 10);

    // Create user
    const user = await db.user.create({
      data: {
        name,
        email: email.toLowerCase(),
        password: hashedPassword,
        role: 'CUSTOMER',
        emailVerified: null, // Set to null - send verification email
      },
    });

    // TODO: Send verification email

    return NextResponse.json(
      {
        message: 'Account created successfully',
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('[Auth Register API] Error:', error);
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    );
  }
}

// ============================================

// app/api/auth/signout/route.ts
/**
 * POST /api/auth/signout
 * 
 * Clears session and removes refresh tokens
 */
export async function POST(request: NextRequest) {
  try {
    const response = NextResponse.json(
      { message: 'Signed out successfully' },
      { status: 200 }
    );

    // Clear authentication cookies
    response.cookies.set('next-auth.session-token', '', {
      maxAge: 0,
      path: '/',
    });

    response.cookies.set('next-auth.csrf-token', '', {
      maxAge: 0,
      path: '/',
    });

    response.cookies.set('next-auth.callback-url', '', {
      maxAge: 0,
      path: '/',
    });

    return response;
  } catch (error) {
    console.error('[Auth Signout API] Error:', error);
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    );
  }
}

// ============================================

// lib/auth.ts - NextAuth Configuration
import type { NextAuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import { compare } from 'bcryptjs';
import type { JWT } from 'next-auth/jwt';
import type { Session } from 'next-auth';

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: 'Credentials',
      credentials: {
        email: { label: 'Email', type: 'email', placeholder: 'you@example.com' },
        password: { label: 'Password', type: 'password' },
      },
      async authorize(credentials, req) {
        if (!credentials?.email || !credentials?.password) {
          throw new Error('Invalid credentials');
        }

        const user = await db.user.findUnique({
          where: { email: credentials.email.toLowerCase() },
        });

        if (!user) {
          throw new Error('No user found with this email');
        }

        const isPasswordValid = await compare(credentials.password, user.password);

        if (!isPasswordValid) {
          throw new Error('Invalid password');
        }

        // Check if account is active
        if (user.disabled) {
          throw new Error('Account has been disabled');
        }

        return {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          image: user.image,
        };
      },
    }),
  ],

  session: {
    strategy: 'jwt',
    maxAge: 30 * 24 * 60 * 60, // 30 days
    updateAge: 24 * 60 * 60, // Update every 24 hours
  },

  jwt: {
    secret: process.env.NEXTAUTH_SECRET,
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },

  callbacks: {
    // JWT callback - runs when token is created/updated
    async jwt({ token, user }: { token: JWT; user?: any }) {
      if (user) {
        token.id = user.id;
        token.role = user.role;
        token.email = user.email;
        token.name = user.name;
      }

      // Refresh user data periodically
      if (Date.now() > (token.iat || 0) * 1000 + 24 * 60 * 60 * 1000) {
        const dbUser = await db.user.findUnique({
          where: { id: token.id as string },
        });

        if (dbUser) {
          token.role = dbUser.role;
          token.name = dbUser.name;
        }
      }

      return token;
    },

    // Session callback - runs when session is accessed
    async session({ session, token }: { session: Session; token: JWT }) {
      if (session.user) {
        session.user.id = token.id;
        session.user.role = token.role;
      }
      return session;
    },

    // SignIn callback - runs after successful sign in
    async signIn({ user, account, profile, email, credentials }) {
      // Add additional checks here
      // e.g., check if email is verified, user is active, etc.

      // Log successful sign in
      console.log('[Auth] User signed in:', user.email);

      return true;
    },

    // Redirect callback - controls redirect after sign in
    async redirect({ url, baseUrl }) {
      // Only allow redirects to same origin
      if (url.startsWith('/')) return `${baseUrl}${url}`;
      else if (new URL(url).origin === baseUrl) return url;
      return baseUrl;
    },
  },

  pages: {
    signIn: '/login',
    error: '/login',
    newUser: '/register',
  },

  events: {
    async signIn({ user, account, profile, isNewUser }) {
      console.log('[Auth Event] User signed in:', user.email);
      // Log to analytics, send email notification, etc.
    },

    async signOut({ token }) {
      console.log('[Auth Event] User signed out:', token.email);
      // Cleanup, log to analytics, etc.
    },

    async session({ session, token }) {
      // Optional: Log session activity
    },
  },

  // Error page handling
  logger: {
    error: (code, metadata) => {
      console.error('[NextAuth Error]', code, metadata);
    },
    warn: (code) => {
      console.warn('[NextAuth Warn]', code);
    },
    debug: (code, metadata) => {
      if (process.env.NODE_ENV === 'development') {
        console.debug('[NextAuth Debug]', code, metadata);
      }
    },
  },

  // Debug mode in development
  debug: process.env.NODE_ENV === 'development',
};
