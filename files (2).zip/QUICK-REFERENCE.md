# QUICK REFERENCE GUIDE

## 🎯 Copy-Paste Quick Starts

### 1. Check if User is Authenticated

```typescript
'use client';
import { useAuthSession } from '@/hooks/useAuthSession';

export function MyComponent() {
  const { session, status, isHydrated } = useAuthSession();
  
  if (!isHydrated || status === 'loading') {
    return <div>Loading...</div>;
  }
  
  if (status === 'authenticated') {
    return <div>Welcome, {session?.user?.name}!</div>;
  }
  
  return <div>Please sign in</div>;
}
```

---

### 2. Check if User is Admin

```typescript
'use client';
import { useIsAdmin } from '@/hooks/useAuthSession';

export function AdminPanel() {
  const isAdmin = useIsAdmin();
  
  if (!isAdmin) {
    return <div>Access Denied</div>;
  }
  
  return <div>Admin Controls</div>;
}
```

---

### 3. Navigate to Tab with Deep-Link

```typescript
'use client';
import { useRouter } from 'next/navigation';

export function OrdersButton() {
  const router = useRouter();
  
  return (
    <button 
      onClick={() => router.push('/account?tab=orders')}
    >
      View My Orders
    </button>
  );
}
```

---

### 4. Sign Out User

```typescript
'use client';
import { signOut } from 'next-auth/react';

export function SignOutButton() {
  const handleSignOut = async () => {
    await signOut({ redirect: true, callbackUrl: '/' });
  };
  
  return <button onClick={handleSignOut}>Sign Out</button>;
}
```

---

### 5. Protect a Page from Unauthenticated Users

```typescript
'use client';
import { useAuthSession } from '@/hooks/useAuthSession';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function ProtectedPage() {
  const { status, isHydrated } = useAuthSession();
  const router = useRouter();
  
  useEffect(() => {
    if (!isHydrated) return;
    if (status === 'unauthenticated') {
      router.replace('/login');
    }
  }, [isHydrated, status, router]);
  
  if (!isHydrated || status === 'loading') {
    return <div>Loading...</div>;
  }
  
  if (status === 'unauthenticated') {
    return <div>Redirecting...</div>;
  }
  
  return <div>Protected Content</div>;
}
```

---

### 6. Get Current User Info

```typescript
'use client';
import { useAuthSession } from '@/hooks/useAuthSession';

export function UserProfile() {
  const { session, isHydrated } = useAuthSession();
  
  if (!isHydrated || !session) {
    return <div>No user</div>;
  }
  
  return (
    <div>
      <h1>{session.user?.name}</h1>
      <p>{session.user?.email}</p>
      <p>Role: {session.user?.role}</p>
    </div>
  );
}
```

---

## 🔐 Common Security Patterns

### Require Authentication Middleware

```typescript
// middleware.ts
export const config = {
  matcher: ['/account/:path*', '/admin/:path*'],
};

export async function middleware(request: NextRequest) {
  const token = await getToken({ req: request });
  
  if (!token) {
    const loginUrl = new URL('/login', request.url);
    loginUrl.searchParams.set('callbackUrl', request.nextUrl.pathname);
    return NextResponse.redirect(loginUrl);
  }
  
  return NextResponse.next();
}
```

---

### Require Admin Role

```typescript
// middleware.ts
export async function middleware(request: NextRequest) {
  const token = await getToken({ req: request });
  
  if (token?.role !== 'ADMIN') {
    return NextResponse.redirect(new URL('/account', request.url));
  }
  
  return NextResponse.next();
}
```

---

### Rate Limiting on Login (Node.js)

```typescript
// app/api/auth/login/route.ts
import rateLimit from 'express-rate-limit';

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 attempts
  message: 'Too many login attempts, try again later'
});

export async function POST(request: NextRequest) {
  // Apply rate limiter
  await limiter(request);
  
  // ... handle login
}
```

---

### Validate Callback URL

```typescript
function isValidCallbackUrl(url: string | null, baseUrl: string): boolean {
  if (!url) return false;
  
  // Must start with /
  if (!url.startsWith('/')) return false;
  
  // Cannot be auth pages
  if (url.startsWith('/login') || url.startsWith('/register')) {
    return false;
  }
  
  // Cannot access admin if not admin
  if (url.startsWith('/admin')) {
    // This check is more complex, do it in callback
    return true;
  }
  
  return true;
}
```

---

## 🎨 Styling Utilities

### Gradient Backgrounds (Admin)

```css
/* Cyan gradient for admin users */
.admin-gradient {
  background: linear-gradient(135deg, #06b6d4, #0891b2);
}

/* Blue gradient for customers */
.customer-gradient {
  background: linear-gradient(135deg, #3b82f6, #1e40af);
}
```

---

### Button States

```css
/* Loading state */
.btn:disabled {
  @apply opacity-50 cursor-not-allowed;
}

/* Focus state */
.btn:focus {
  @apply ring-2 ring-offset-2 ring-blue-500;
}

/* Hover state */
.btn:hover:not(:disabled) {
  @apply brightness-110;
}
```

---

## 📝 Form Validation Patterns

### Email Validation

```typescript
const isValidEmail = (email: string): boolean => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};
```

---

### Password Strength Check

```typescript
function getPasswordStrength(password: string): 'weak' | 'fair' | 'strong' {
  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumbers = /\d/.test(password);
  const hasSpecialChar = /[!@#$%^&*]/.test(password);
  const isLong = password.length >= 12;

  if (hasUpperCase && hasLowerCase && hasNumbers && isLong) {
    return 'strong';
  }
  if (hasUpperCase && hasLowerCase && hasNumbers) {
    return 'fair';
  }
  return 'weak';
}
```

---

### Form Error Handling

```typescript
const [errors, setErrors] = useState<Record<string, string>>({});

const validateForm = (formData: any): boolean => {
  const newErrors: Record<string, string> = {};
  
  if (!formData.email) {
    newErrors.email = 'Email is required';
  }
  
  if (formData.password.length < 8) {
    newErrors.password = 'Password must be at least 8 characters';
  }
  
  setErrors(newErrors);
  return Object.keys(newErrors).length === 0;
};
```

---

## 🔄 API Examples

### Fetch Current Session

```typescript
const response = await fetch('/api/auth/session', {
  method: 'GET',
  headers: { 'Cache-Control': 'no-cache' },
  credentials: 'include',
});

const session = await response.json();
```

---

### Register New User

```typescript
const response = await fetch('/api/auth/register', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'John Doe',
    email: 'john@example.com',
    password: 'SecurePass123!',
  }),
});

const data = await response.json();
```

---

### Update User Profile

```typescript
const response = await fetch('/api/user/profile', {
  method: 'PUT',
  headers: { 'Content-Type': 'application/json' },
  credentials: 'include',
  body: JSON.stringify({
    name: 'John Doe Updated',
    phone: '+91-1234567890',
  }),
});
```

---

## 🧪 Testing Helpers

### Mock useAuthSession

```typescript
jest.mock('@/hooks/useAuthSession', () => ({
  useAuthSession: jest.fn(() => ({
    session: {
      user: { id: '1', name: 'Test User', email: 'test@example.com' },
    },
    status: 'authenticated',
    isHydrated: true,
    isRefreshing: false,
    error: null,
  })),
}));
```

---

### Test Protected Route

```typescript
it('redirects to login if not authenticated', async () => {
  (useAuthSession as jest.Mock).mockReturnValue({
    status: 'unauthenticated',
    isHydrated: true,
  });
  
  render(<ProtectedPage />);
  
  expect(useRouter().replace).toHaveBeenCalledWith('/login');
});
```

---

## 📊 Database Queries

### Create User

```typescript
const user = await db.user.create({
  data: {
    name: 'John Doe',
    email: 'john@example.com',
    password: hashedPassword, // Use bcryptjs
    role: 'CUSTOMER',
  },
});
```

---

### Find User by Email

```typescript
const user = await db.user.findUnique({
  where: { email: email.toLowerCase() },
});
```

---

### Update User

```typescript
const updated = await db.user.update({
  where: { id: userId },
  data: {
    name: 'Updated Name',
    phone: '+91-1234567890',
  },
});
```

---

### Get User with Relations

```typescript
const user = await db.user.findUnique({
  where: { id: userId },
  include: {
    orders: true,
    addresses: true,
  },
});
```

---

## 🚀 Deployment Checklist

### Vercel Deployment

```bash
# 1. Push to GitHub
git push origin main

# 2. Import project in Vercel dashboard
# 3. Add environment variables:
NEXTAUTH_SECRET=your-secret
NEXTAUTH_URL=https://yourdomain.com
DATABASE_URL=your-production-db

# 4. Deploy
vercel deploy --prod
```

---

### Docker Deployment

```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci

COPY . .
RUN npm run build

ENV NODE_ENV=production
ENV NEXTAUTH_SECRET=${NEXTAUTH_SECRET}
ENV NEXTAUTH_URL=${NEXTAUTH_URL}

EXPOSE 3000

CMD ["npm", "start"]
```

---

## 🔍 Debugging Tips

### Enable NextAuth Debug Mode

```typescript
// lib/auth.ts
export const authOptions: NextAuthOptions = {
  // ...
  debug: true, // Logs auth flow
};
```

---

### Check Session in Browser Console

```javascript
// In browser console
fetch('/api/auth/session')
  .then(r => r.json())
  .then(console.log);
```

---

### Inspect JWT Token

```javascript
// Decode JWT (client-side, debug only)
const token = document.cookie
  .split('; ')
  .find(row => row.startsWith('next-auth'))
  ?.split('=')[1];

const decoded = JSON.parse(atob(token.split('.')[1]));
console.log(decoded);
```

---

### Check Middleware Execution

```typescript
// middleware.ts
export async function middleware(request: NextRequest) {
  console.log('[Middleware] Path:', request.nextUrl.pathname);
  console.log('[Middleware] Token:', await getToken({ req: request }));
  return NextResponse.next();
}
```

---

## 📱 Mobile Optimization

### Touch-Friendly Button Size

```css
.btn {
  min-height: 44px; /* Apple recommended for touch */
  min-width: 44px;
  padding: 12px 16px;
}
```

---

### Safe Area Insets

```css
.drawer {
  padding-top: env(safe-area-inset-top);
  padding-bottom: env(safe-area-inset-bottom);
}
```

---

### Viewport Configuration

```html
<!-- In HTML head -->
<meta 
  name="viewport" 
  content="width=device-width, initial-scale=1, viewport-fit=cover"
>
```

---

## 🎯 Common Tasks

### How to Add OAuth (Google)

```typescript
import GoogleProvider from 'next-auth/providers/google';

export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID || '',
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || '',
    }),
    // ... CredentialsProvider
  ],
};
```

---

### How to Add Email Verification

```typescript
// After user registration
const token = generateRandomToken();

await db.emailVerification.create({
  data: {
    userId,
    token,
    expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24h
  },
});

// Send verification email
await sendEmail({
  to: email,
  subject: 'Verify your email',
  html: `Click here to verify: ${baseUrl}/verify?token=${token}`,
});
```

---

### How to Add Session Timeout

```typescript
const SESSION_IDLE_TIMEOUT = 30 * 60 * 1000; // 30 minutes

export function SessionTimeout() {
  const { signOut } = useAuth();
  const timeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    const resetTimeout = () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      
      timeoutRef.current = setTimeout(() => {
        signOut();
      }, SESSION_IDLE_TIMEOUT);
    };

    window.addEventListener('mousemove', resetTimeout);
    window.addEventListener('keypress', resetTimeout);

    return () => {
      window.removeEventListener('mousemove', resetTimeout);
      window.removeEventListener('keypress', resetTimeout);
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [signOut]);

  return null;
}
```

---

## 📞 Need Help?

**Most Common Issues:**

| Issue | Solution |
|-------|----------|
| Session not persisting | Check NEXTAUTH_SECRET is set |
| Always redirects to login | Check middleware config |
| Hydration error | Use isHydrated check |
| Admin access denied | Verify role in JWT |
| Email already exists error | Check user exists in DB |
| Password too weak | Use password strength checker |

---

**Last Updated:** 2024  
**Quick Ref Version:** 1.0
